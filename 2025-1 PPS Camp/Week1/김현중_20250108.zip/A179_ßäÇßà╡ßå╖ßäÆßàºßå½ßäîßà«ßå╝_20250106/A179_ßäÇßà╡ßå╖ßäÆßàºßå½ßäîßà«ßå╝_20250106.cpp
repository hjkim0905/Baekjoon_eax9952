#include <iostream>
using namespace std;

int main() {
  int y;
  cin >> y;
  cout << y - 543 << endl;
  return 0;
}